"""Run the main file"""
__import__("main").main(__import__("tkinter").Tk())
